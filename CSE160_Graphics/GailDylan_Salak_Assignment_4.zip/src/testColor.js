//Vertex shader program
var VSHADER_SOURCE = 
	"attribute vec4 a_Position; \n" +
	"attribute vec4 a_Color;\n" +
	"varying vec4 v_Color;\n" +
	"uniform mat4 u_ModelMatrix;\n" +
	"uniform mat4 u_ProjMatrix;\n" +
	"uniform mat4 u_ViewMatrix;\n" +
	"void main() {\n" +
	"	gl_Position = u_ProjMatrix * u_ViewMatrix * u_ModelMatrix * a_Position;\n" + //Coordinates
	"	v_Color = a_Color;\n" +
	"}\n";

//Fragment shader program
var FSHADER_SOURCE = 
	"precision mediump float;\n" +
	"uniform float u_Tex;\n" +
	"uniform sampler2D u_Sampler0;\n" +
	"uniform sampler2D u_Sampler1;\n" +
	"uniform sampler2D u_Sampler2;\n" +
	"uniform sampler2D u_Sampler3;\n" +
	"uniform sampler2D u_Sampler4;\n" +
	"varying vec4 v_Color;\n" +
	"void main() {\n" +
	"	float tex = u_Tex;\n" +
	"	if (tex == 0.0){\n" +
	"		gl_FragColor = texture2D(u_Sampler0, vec2(v_Color[0], v_Color[1]));\n" + //Obsidian
	"	} else if (tex == 1.0){\n" +
	"		gl_FragColor = texture2D(u_Sampler1, vec2(v_Color[0], v_Color[1]));\n" + //Sky
	"	} else if (tex == 2.0){\n" +
	"		gl_FragColor = texture2D(u_Sampler2, vec2(v_Color[0], v_Color[1]));\n" + //End Stone
	"	} else if (tex == 3.0){\n" +
	"		gl_FragColor = texture2D(u_Sampler3, vec2(v_Color[0], v_Color[1]));\n" + //Bedrock
	"	} else if (tex == 4.0){\n" +
	"		gl_FragColor = texture2D(u_Sampler4, vec2(v_Color[0], v_Color[1]));\n" + //Egg
	"	}\n" +
	"}\n";

//TO FIX IT BACK TO JUST ONE TEXTURE
//get rid of u_Sampler1 and all its traces in initTextures and loadTexture
//delete u_Tex from everything


//GLOBAL VARIABLES
var viewMatrix = new Matrix4();	//ViewMatrix
var projMatrix = new Matrix4(); //ProjectionMatrix
var eye = [31, 5, 50];
var at = [31, 5, 49];
var up = [0, 1, 0];

var CUBE_UNIT = 1.0			//unit of each side

function main() {
	console.log("beginning of main: eye = "+eye);
	//Retrieve <canvas> element
	var canvas = document.getElementById("webgl");
	if (!canvas){
		console.log("Failed to retrieve the <canvas> element");
		return;
	}

	//Get the rendering context for WebGL
	var gl = getWebGLContext(canvas);
	if (!gl){
		console.log("Failed to get the rendering context for WebGL");
		return;
	}

	//enabling depth test for 3D geometries
	gl.enable(gl.DEPTH_TEST);

	//Initialize shaders
	if (!createShaderProgram(gl, VSHADER_SOURCE, FSHADER_SOURCE)){
		console.log("Failed to initialize shaders.");
		return;
	}

	//Get the storage location of the attribute variables
	var a_Position = gl.getAttribLocation(gl.program, "a_Position");
	if (a_Position < 0){
		console.log("Failed to get the storage location of a_Position");
		return;
	}

	//initialize the vertex buffers
	var n = initVertexBuffers(gl);
	if (n < 0){
		console.log("Failed to set the positions of the vertices");
		return;
	}

	//set the textures
	if (!initTextures(gl,n)){
		console.log("Failed to set the textures");
		return;
	}

	var u_ProjMatrix = gl.getUniformLocation(gl.program, "u_ProjMatrix");
	var u_ViewMatrix = gl.getUniformLocation(gl.program, "u_ViewMatrix");

	//setting the perspective through the projection matrix
	//(only needs to be done once)
	projMatrix.setPerspective(60, 1, 0.1, 1000);
	gl.uniformMatrix4fv(u_ProjMatrix, false, projMatrix.elements);

	//register the event handler to be called on key press
	document.onkeydown = function(ev){keydown(ev, gl);};
}

function renderScene(gl){
	//Specify the color for clearing <canvas>
	gl.clearColor(0.0, 0.0, 0.0, 1.0);
	//Clear <canvas>
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	var u_Tex = gl.getUniformLocation(gl.program, "u_Tex");
	var u_FragColor = gl.getUniformLocation(gl.program, "u_FragColor");

	var modelMatrix = new Matrix4;

	//sky cube
	modelMatrix.setScale(32.0, 50.0, 32.0);
	modelMatrix.translate(1.0, 0.0, 1.0);
	gl.uniform4f(u_FragColor, 0.6, 0.8, 1.0, 1.0);
	gl.uniform1f(u_Tex, 1.0);	//u_Tex set for texture 1
	drawCube(gl, modelMatrix);

	//ground cube
	modelMatrix.setScale(32.0, 1.0, 32.0);
	modelMatrix.translate(1.0, -2.0, 1.0);
	gl.uniform1f(u_Tex, 2.0);	//u_Tex set for texture 2
	drawCube(gl, modelMatrix);

	var map = [];	//each index of map is a separate level

	map[0] = [[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//1
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//2
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//3
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//4
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//5
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//6
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//7
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//8
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//9
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//10
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//11
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//12
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//13
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//14
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//15
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//16
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//17
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//18
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//19
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//20
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//21
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//22
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//23
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//24
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//25
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//26
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//27
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//28
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//29
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//30
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//31
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]];//32

	map[1] = [[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//1
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//2
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,1,1,1,1,0,0,0],//3
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,1,1,1,1,1,1,0,0],//4
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,1,1,1,1,1,1,0,0],//5
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//9
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2],//10
			  [2,2,2,2,2,2,2,2,2,2,2,2],//11
			  [2,2,2,2,2,2,2,2,2,2,2,2],//12
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,3,3,3],//13
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,0,3,4,4,4,3],//14
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,3,4,4,4,4,4,3],//15
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,3,4,4,3,4,4,3],//16
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,3,4,4,4,4,4,3,0,0,0,0,0,0,0,0,0,2,2,2],//17
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,3,4,4,4,3,0,0,0,0,0,0,0,0,0,2,2,2,2],//18
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,3,3,3,0,0,0,0,0,0,2,2,2,2,2,2,2,2],//19
			  [2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2],//20
			  [2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2],//21
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2],//22
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2],//23
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2],//24
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//25
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//26
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//27
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//28
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//29
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//30
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//31
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]];//32

	map[2] = [[0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2],//1
			  [0,0,0,1,1,1,0,0,0,0,2,2,2,2,2,2,2,2,2],//2
			  [0,0,1,1,1,1,1,0,0,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0,0,0,0,0,2,2,2,2,2,2,2],//9
			  [0,0,2,2,2,2,2,2,2,2,2],//10
			  [0,0,2,2,2,2,2,2,2,2],//11
			  [0,2,2,2,2,2,2,2,2],//12
			  [2,2,2,2,2,2,2,2,2],//13
			  [2,2,2,2,2,2,2,2],//14
			  [2,2,2,2,2,2,2],//15
			  [2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,3],//16
			  [2,2,2,2,2,2,2],//17
			  [2,2,2,2,2,2,2],//18
			  [2,2,2,2,2,2,2,2],//19
			  [2,2,2,2,2,2,2,2],//20
			  [2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2],//21
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2],//22
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2],//23
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2],//24
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,2,2,2,2,2,2,2,2,2,2,2],//25
			  [2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,2,1,1,1,2,2,2,2],//26
			  [2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,2,2,2,1,1,1,1,1,2,2,2],//27
			  [2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,2,2,2,2,1,1,1,1,1,2,2,2],//28
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,2,2,2,2,2,2,1,1,1,1,1,2,2,2],//29
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,2,2,2,2,2,2,2,2,1,1,1,2,2,2,2],//30
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],//31
			  [2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]];//32

	map[3] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3],//16
			  [2,2],//17
			  [2,2,2],//18
			  [2,2,2],//19
			  [2,2,2],//20
			  [2,2,2,2],//21
			  [2,2,2,2,2,2],//22
			  [2,2,2,2,2,2,2],//23
			  [2,2,2,2,2,2,2,2],//24
			  [2,2,2,2,2,2,2,2,2,2],//25
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [2,2,2,2,2,2,2,2,2,2,2,2,2],//31
			  [2,2,2,2,2,2,2,2,2,2,2,2,2]];//32

	map[4] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[5] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,5],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[6] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[7] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[8] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[9] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[10] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[11] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[12] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//3
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//4
			  [0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//5
			  [0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//6
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,0,0],//7
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[13] = [[0],//1
			  [0,0,0,1,1,1],//2
			  [0,0,1,1,1,1,1],//3
			  [0,0,1,1,1,1,1],//4
			  [0,0,1,1,1,1,1],//5
			  [0,0,0,1,1,1],//6
			  [0],//7
			  [0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[14] = [[0],//1
			  [0],//2
			  [0],//3
			  [0],//4
			  [0],//5
			  [0],//6
			  [0],//7
			  [0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//26
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//27
			  [0,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//28
			  [0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0],//29
			  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0],//30
			  [0],//31
			  [0]];//32

	map[15] = [[0],//1
			  [0],//2
			  [0],//3
			  [0],//4
			  [0],//5
			  [0],//6
			  [0],//7
			  [0],//8
			  [0],//9
			  [0],//10
			  [0],//11
			  [0],//12
			  [0],//13
			  [0],//14
			  [0],//15
			  [0],//16
			  [0],//17
			  [0],//18
			  [0],//19
			  [0],//20
			  [0],//21
			  [0],//22
			  [0],//23
			  [0,0,1,1,1,1],//24
			  [0,1,1,1,1,1,1],//25
			  [0,1,1,1,1,1,1],//26
			  [0,1,1,1,1,1,1],//27
			  [0,1,1,1,1,1,1],//28
			  [0,0,1,1,1,1],//29
			  [0],//30
			  [0],//31
			  [0]];//32


	var mapCube = 0;
	for (var y = 0; y < map.length; y++){
		for (var x = 0; x < map[y].length; x++){
			for (var z = 0; z < map[y][x].length; z++){
				if (map[y][x][z] == 1){		//obsidian
					modelMatrix.setTranslate((x*2)+1, y*2, (z*2)+1);
					gl.uniform1f(u_Tex, 0.0);
					drawCube(gl, modelMatrix);
					mapCube += 1;
				} else if (map[y][x][z] == 2){	//end stone
					modelMatrix.setTranslate((x*2)+1, y*2, (z*2)+1);
					gl.uniform1f(u_Tex, 2.0);
					drawCube(gl, modelMatrix);
					mapCube += 1;
				} else if (map[y][x][z] == 3){	//bedrock
					modelMatrix.setTranslate((x*2)+1, y*2, (z*2)+1);
					gl.uniform1f(u_Tex, 3.0);
					drawCube(gl, modelMatrix);
					mapCube += 1;
				} else if (map[y][x][z] == 4){	//sky
					modelMatrix.setTranslate((x*2)+1, y*2, (z*2)+1);
					gl.uniform1f(u_Tex, 1.0);
					drawCube(gl, modelMatrix);
					mapCube += 1;
				} else if (map[y][x][z] == 5){	//egg
					modelMatrix.setTranslate((x*2)+1, y*2, (z*2)+1);
					gl.uniform1f(u_Tex, 4.0);
					drawCube(gl, modelMatrix);
					mapCube += 1;
				}
			}
		}
	}
	console.log("mapCube = " + mapCube);
}

function keydown(ev, gl){
	var direction = [0, 0, 0];
	var eyeAt = [0, 0, 0];

	//calculate eyeAt as the vector from eye to at
	eyeAt[0] = (at[0] - eye[0]);
	eyeAt[1] = (at[1] - eye[1]);
	eyeAt[2] = (at[2] - eye[2]);
	eyeAt = normalize(eyeAt);	//normalizing eyeAt


	console.log("eyeAt = " + eyeAt);

	if (ev.keyCode == 87){	//W (forward)

		at[0] += eyeAt[0];
		at[1] += eyeAt[1];
		at[2] += eyeAt[2];

		eye[0] += eyeAt[0];
		eye[1] += eyeAt[1];
		eye[2] += eyeAt[2];

	} else if (ev.keyCode == 83){	//S (backward)

		at[0] -= eyeAt[0];
		at[1] -= eyeAt[1];
		at[2] -= eyeAt[2];

		eye[0] -= eyeAt[0];
		eye[1] -= eyeAt[1];
		eye[2] -= eyeAt[2];

	} else if (ev.keyCode == 65){	//A (left)

		direction = crossproduct(eyeAt, up); 
		direction = normalize(direction);	
		at[0] -= direction[0];
		at[1] -= direction[1];
		at[2] -= direction[2];

		eye[0] -= direction[0];
		eye[1] -= direction[1];
		eye[2] -= direction[2];

	} else if (ev.keyCode == 68){	//D (right)

		direction = crossproduct(eyeAt, up);
		direction = normalize(direction);
		at[0] += direction[0];
		at[1] += direction[1];
		at[2] += direction[2];

		eye[0] += direction[0];
		eye[1] += direction[1];
		eye[2] += direction[2];

	} else if (ev.keyCode == 81){	//Q (turn left)

		let atVec = new Vector3(eyeAt);

		let rotationMat = new Matrix4();
		rotationMat.setRotate(10, up[0], up[1], up[2]);	//rotation matrix around the up vector
		
		//rotate eyeAt vector through rotation matrix
		eyeAt = rotationMat.multiplyVector3(atVec).elements;

		//set at point to new rotated eyeAt vector
		//MUST add the eye point to centralize the rotation at the camera location
		//or else it would rotate around the origin
		at[0] = eyeAt[0] + eye[0];
		at[1] = eyeAt[1] + eye[1];
		at[2] = eyeAt[2] + eye[2];

	} else if (ev.keyCode == 69){	//E (turn right)

		let atVec = new Vector3(eyeAt);

		let rotationMat = new Matrix4();
		rotationMat.setRotate(-10, up[0], up[1], up[2]); //rotation matrix around the up vector

		//rotate eyeAt vector through rotation matrix
		eyeAt = rotationMat.multiplyVector3(atVec).elements;

		//set at point to new rotated eyeAt vector
		//MUST add the eye point to centralize the rotation at the camera location
		//or else it would rotate around the origin
		at[0] = eyeAt[0] + eye[0];
		at[1] = eyeAt[1] + eye[1];
		at[2] = eyeAt[2] + eye[2];

	} else if (ev.keyCode == 82){	//R (turn up!)

		direction = crossproduct(eyeAt, up);
		direction = normalize(direction);

		let atVec = new Vector3(eyeAt);
		let upVec = new Vector3(up);

		let rotationMat = new Matrix4();
		rotationMat.setRotate(10, direction[0], direction[1], direction[2]);

		eyeAt = rotationMat.multiplyVector3(atVec).elements;
		eyeAt = normalize(eyeAt);

		up = rotationMat.multiplyVector3(upVec).elements;
		up = normalize(up);

		at[0] = eyeAt[0] + eye[0];
		at[1] = eyeAt[1] + eye[1];
		at[2] = eyeAt[2] + eye[2];

	} else if (ev.keyCode == 70){	//F (turn down)

		direction = crossproduct(eyeAt, up);
		direction = normalize(direction);

		let atVec = new Vector3(eyeAt);
		let upVec = new Vector3(up);

		let rotationMat = new Matrix4();
		rotationMat.setRotate(-10, direction[0], direction[1], direction[2]);

		eyeAt = rotationMat.multiplyVector3(atVec).elements;
		eyeAt = normalize(eyeAt);

		up = rotationMat.multiplyVector3(upVec).elements;
		up = normalize(up);

		at[0] = eyeAt[0] + eye[0];
		at[1] = eyeAt[1] + eye[1];
		at[2] = eyeAt[2] + eye[2];

	} else return;	//prevent unnecessary drawing
	renderScene(gl);
}

function crossproduct(v1, v2){
	var result = [0,0,0];
	result[0] = (v1[1] * v2[2]) - (v2[1] * v1[2])
	result[1] = (v1[0] * v2[2]) - (v2[0] * v1[2])
	result[2] = (v1[0] * v2[1]) - (v2[0] * v1[1])
	return result;
}

function normalize(v){
	var norm = Math.sqrt((v[0]*v[0]) + (v[1]*v[1]) + (v[2]*v[2]));
	v[0] = v[0] / norm;
	v[1] = v[1] / norm;
	v[2] = v[2] / norm;
	return v;
}

var vertices = new Float32Array(18);	//Float32Array that holds the 9 coordinates per triangle
function initVertexBuffers(gl){

	var n = 6; //the number of vertices

	//create a buffer object (1)
	var vertexBuffer = gl.createBuffer();
	if (!vertexBuffer){
		console.log("Failed to create the buffer object");
		return -1;
	}

	//bind the buffer object to target (2)
	gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
	//Write data into the buffer object (3)
	gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

	var FSIZE = vertices.BYTES_PER_ELEMENT;
	//get the storage location of attribute variables
	var a_Position = gl.getAttribLocation(gl.program, "a_Position");
	if (a_Position < 0){
		console.log("Failed to get the storage location of a_Position");
		return;
	}

	//Assign the buffer object to a_Position variable (4)
	gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, FSIZE*6, 0);
	//Enable the assignment to a_Position variable (5)
	gl.enableVertexAttribArray(a_Position);

	var a_Color = gl.getAttribLocation(gl.program, "a_Color");
	if (a_Color < 0){
		console.log("Failed to get the storage location of a_Color");
		return;
	}

	//Assign the buffer object to a_Position variable (4)
	gl.vertexAttribPointer(a_Color, 3, gl.FLOAT, false, FSIZE*6, FSIZE*3);
	//Enable the assignment to a_Position variable (5)
	gl.enableVertexAttribArray(a_Color);

	return n;
}

function initTextures(gl, n) {

  var texture0 = gl.createTexture();   // Create a texture object (Obsidian)
  if (!texture0) {
    console.log('Failed to create the texture0 object');
    return false;
  }

  // Get the storage location of u_Sampler0
  var u_Sampler0 = gl.getUniformLocation(gl.program, 'u_Sampler0');
  if (!u_Sampler0) {
    console.log('Failed to get the storage location of u_Sampler0');
    return false;
  }
  var image0 = new Image();  // Create the image object
  if (!image0) {
    console.log('Failed to create the image0 object');
    return false;
  }
  // Register the event handler to be called on loading an image
  image0.onload = function(){ loadTexture(gl, n, texture0, u_Sampler0, image0, 0); };
  // Tell the browser to load an image
  image0.src = 'src/obsidian.jpg';

  //------------------------------------------------

  var texture1 = gl.createTexture();   // Create a texture object (Sky)
  if (!texture1) {
    console.log('Failed to create the texture1 object');
    return false;
  }

  // Get the storage location of u_Sampler1
  var u_Sampler1 = gl.getUniformLocation(gl.program, 'u_Sampler1');
  if (!u_Sampler1) {
    console.log('Failed to get the storage location of u_Sampler1');
    return false;
  }
  var image1 = new Image();  // Create the image object
  if (!image1) {
    console.log('Failed to create the image1 object');
    return false;
  }
  // Register the event handler to be called on loading an image
  image1.onload = function(){ loadTexture(gl, n, texture1, u_Sampler1, image1, 1); };
  // Tell the browser to load an image
  image1.src = 'src/sky.jpg';

  //------------------------------------------------

  var texture2 = gl.createTexture();   // Create a texture object (Endstone)
  if (!texture2) {
    console.log('Failed to create the texture2 object');
    return false;
  }

  // Get the storage location of u_Sampler2
  var u_Sampler2 = gl.getUniformLocation(gl.program, 'u_Sampler2');
  if (!u_Sampler2) {
    console.log('Failed to get the storage location of u_Sampler2');
    return false;
  }
  var image2 = new Image();  // Create the image object
  if (!image2) {
    console.log('Failed to create the image2 object');
    return false;
  }
  // Register the event handler to be called on loading an image
  image2.onload = function(){ loadTexture(gl, n, texture2, u_Sampler2, image2, 2); };
  // Tell the browser to load an image
  image2.src = 'src/endstone.jpg';

  //------------------------------------------------

  var texture3 = gl.createTexture();   // Create a texture object (Bedrock)
  if (!texture3) {
    console.log('Failed to create the texture3 object');
    return false;
  }

  // Get the storage location of u_Sampler2
  var u_Sampler3 = gl.getUniformLocation(gl.program, 'u_Sampler3');
  if (!u_Sampler3) {
    console.log('Failed to get the storage location of u_Sampler3');
    return false;
  }
  var image3 = new Image();  // Create the image object
  if (!image3) {
    console.log('Failed to create the image3 object');
    return false;
  }
  // Register the event handler to be called on loading an image
  image3.onload = function(){ loadTexture(gl, n, texture3, u_Sampler3, image3, 3); };
  // Tell the browser to load an image
  image3.src = 'src/bedrock.jpg';

  //------------------------------------------------

  var texture4 = gl.createTexture();   // Create a texture object (Egg)
  if (!texture4) {
    console.log('Failed to create the texture4 object');
    return false;
  }

  // Get the storage location of u_Sampler2
  var u_Sampler4 = gl.getUniformLocation(gl.program, 'u_Sampler4');
  if (!u_Sampler4) {
    console.log('Failed to get the storage location of u_Sampler4');
    return false;
  }
  var image4 = new Image();  // Create the image object
  if (!image4) {
    console.log('Failed to create the image4 object');
    return false;
  }
  // Register the event handler to be called on loading an image
  image4.onload = function(){ loadTexture(gl, n, texture4, u_Sampler4, image4, 4); };
  // Tell the browser to load an image
  image4.src = 'src/egg.jpg';

  return true;
}

//Specify whether the texture unit is ready to use
var texUnit0 = false;
var texUnit1 = false;
var texUnit2 = false;
var texUnit3 = false;
var texUnit4 = false;
function loadTexture(gl, n, texture, u_Sampler, image, texUnit) {
  gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 1); // Flip the image's y axis

  // Activate all the texture units
  if (texUnit == 0){
  	gl.activeTexture(gl.TEXTURE0);
  	texUnit0 = true;
  } else if (texUnit == 1){
  	gl.activeTexture(gl.TEXTURE1);
  	texUnit1 = true;
  } else if (texUnit == 2){
  	gl.activeTexture(gl.TEXTURE2);
  	texUnit2 = true;
  } else if (texUnit == 3){
  	gl.activeTexture(gl.TEXTURE3);
  	texUnit3 = true;
  } else if (texUnit == 4){
  	gl.activeTexture(gl.TEXTURE4);
  	texUnit4 = true;
  }
  
  // Bind the texture object to the target
  gl.bindTexture(gl.TEXTURE_2D, texture);

  // Set the texture parameters
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  // Set the texture image
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
  
  // Set the texture unit to the sampler
  gl.uniform1i(u_Sampler, texUnit);
  
  gl.clear(gl.COLOR_BUFFER_BIT);   // Clear <canvas>

  if (texUnit0 && texUnit1 && texUnit2 && texUnit3 && texUnit4){
 	 renderScene(gl);
  }
}

var cubecount = 0;
function drawCube(gl, matrix){

	//get locations of all the uniforms being used
	var u_ModelMatrix = gl.getUniformLocation(gl.program, "u_ModelMatrix");
	var u_ViewMatrix = gl.getUniformLocation(gl.program, "u_ViewMatrix");

	//set the view matrix -> eye point and line of sight
	viewMatrix.setLookAt(eye[0], eye[1], eye[2],
						 at[0],	 at[1],  at[2],
						 up[0],  up[1],  up[2]);

	//pass the rotation matrix to the vertex shader
	gl.uniformMatrix4fv(u_ModelMatrix, false, matrix.elements);
	//pass the global rotation matrix to the vertex shader
	gl.uniformMatrix4fv(u_ViewMatrix, false, viewMatrix.elements);

	var cube_points = [
		-CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT, 	  //back face
		-CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,    -CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,
		-CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,   -CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,    -CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,	      //left face
		-CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,   -CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,   -CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,
		 CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,   -CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,   -CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,	  //front face
		 CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,    CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,   -CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,
		 CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,    CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,	  //right face
		 CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,
		-CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,      CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,    CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,        //top face
		-CUBE_UNIT, CUBE_UNIT, CUBE_UNIT,     -CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,    CUBE_UNIT, CUBE_UNIT, -CUBE_UNIT,
		-CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,     CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,   CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,       //bottom face
		-CUBE_UNIT, -CUBE_UNIT, CUBE_UNIT,    -CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,   CUBE_UNIT, -CUBE_UNIT, -CUBE_UNIT,
	]; 

	var length = cube_points.length;
	var half = 1;
	for (var i = 0; i < length; i += 9){
		if (half == 1){
			vertices[0] = cube_points[i];
			vertices[1] = cube_points[i+1];
			vertices[2] = cube_points[i+2];
			vertices[3] = 1.0;
			vertices[4] = 0.0;
			vertices[5] = 0.0;

			vertices[6] = cube_points[i+3];
			vertices[7] = cube_points[i+4];
			vertices[8] = cube_points[i+5];
			vertices[9] = 0.0;
			vertices[10] = 1.0;
			vertices[11] = 0.0;

			vertices[12] = cube_points[i+6];
			vertices[13] = cube_points[i+7];
			vertices[14] = cube_points[i+8];
			vertices[15] = 0.0;
			vertices[16] = 0.0;
			vertices[17] = 0.0;
			half = 0;
		} else if (half == 0){
			vertices[0] = cube_points[i];
			vertices[1] = cube_points[i+1];
			vertices[2] = cube_points[i+2];
			vertices[3] = 1.0;
			vertices[4] = 0.0;
			vertices[5] = 0.0;

			vertices[6] = cube_points[i+3];
			vertices[7] = cube_points[i+4];
			vertices[8] = cube_points[i+5];
			vertices[9] = 1.0;
			vertices[10] = 1.0;
			vertices[11] = 0.0;

			vertices[12] = cube_points[i+6];
			vertices[13] = cube_points[i+7];
			vertices[14] = cube_points[i+8];
			vertices[15] = 0.0;
			vertices[16] = 1.0;
			vertices[17] = 0.0;
			half = 1;
		}

		//write data into the buffer object
		gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

		//Draw the triangle
		gl.drawArrays(gl.TRIANGLES, 0, 3);
		cubecount += 1;
		//console.log("triangles = "+cubecount);
	}
}



